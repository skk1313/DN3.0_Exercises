package search;

public class SearchAlgorithms {
	public static int linearSearch(Product[] products, String productName) {
        for (int i = 0; i < products.length; i++) {
            if (products[i].getProductName().equalsIgnoreCase(productName)) {
                return i;
            }
        }
        return -1;
    }

    // Binary search
    public static int binarySearch(Product[] products, String productName) {
        int left = 0;
        int right = products.length - 1;

        while (left <= right) {
            int middle = left + (right - left) / 2;
            int comparison = products[middle].getProductName().compareToIgnoreCase(productName);

            if (comparison == 0) {
                return middle;
            } else if (comparison < 0) {
                left = middle + 1;
            } else {
                right = middle - 1;
            }
        }
        return -1;
    }
}
//Linear Search:
//Best Case: O(1) (Element found at the first position)
//Average Case: O(n/2) or O(n) (Element found in the middle)
//Worst Case: O(n) (Element not found, searched all elements)
//Binary Search:
//Best Case: O(1) (Element found at the middle position in the first try)
//Average Case: O(log n) (Element found after dividing the array multiple times)
//Worst Case: O(log n) (Element not found, searched through all log n levels of the array)
