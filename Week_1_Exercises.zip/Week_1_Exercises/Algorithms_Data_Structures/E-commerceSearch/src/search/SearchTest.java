package search;
import java.util.Arrays;
public class SearchTest {
	public static void main(String[] args) {
        Product[] products = {
            new Product("P001", "Laptop", "Electronics"),
            new Product("P002", "Smartphone", "Electronics"),
            new Product("P003", "Tablet", "Electronics"),
            new Product("P004", "Monitor", "Electronics"),
            new Product("P005", "Keyboard", "Electronics")
        };

        // Test Linear Search
        String searchName = "Tablet";
        int result = SearchAlgorithms.linearSearch(products, searchName);
        if (result != -1) {
            System.out.println("Linear Search: Found " + products[result]);
        } else {
            System.out.println("Linear Search: Product not found.");
        }

        // Sort array for Binary Search
        Arrays.sort(products, (p1, p2) -> p1.getProductName().compareToIgnoreCase(p2.getProductName()));

        // Test Binary Search
        result = SearchAlgorithms.binarySearch(products, searchName);
        if (result != -1) {
            System.out.println("Binary Search: Found " + products[result]);
        } else {
            System.out.println("Binary Search: Product not found.");
        }
    }

}
//Linear Search is straightforward but less efficient for large datasets, with a time complexity of O(n).
//Binary Search is more efficient for large, sorted datasets, with a time complexity of O(log n).
