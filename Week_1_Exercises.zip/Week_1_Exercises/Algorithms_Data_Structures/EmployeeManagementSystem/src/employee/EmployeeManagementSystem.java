package employee;
import java.util.Arrays;
public class EmployeeManagementSystem {
	private Employee[] employees;
    private int size;
    private int capacity;

    public EmployeeManagementSystem(int capacity) {
        this.capacity = capacity;
        this.employees = new Employee[capacity];
        this.size = 0;
    }

    // Add an employee
    public void addEmployee(Employee employee) {
        if (size < capacity) {
            employees[size] = employee;
            size++;
        } else {
            System.out.println("Array is full. Cannot add more employees.");
        }
    }

    // Search for an employee by employeeId
    public Employee searchEmployee(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                return employees[i];
            }
        }
        return null;
    }

    // Traverse and display all employees
    public void traverseEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    // Delete an employee by employeeId
    public void deleteEmployee(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                // Shift elements to the left to fill the gap
                for (int j = i; j < size - 1; j++) {
                    employees[j] = employees[j + 1];
                }
                employees[size - 1] = null; // Nullify the last element
                size--;
                return;
            }
        }
        System.out.println("Employee not found.");
    }

    public static void main(String[] args) {
        EmployeeManagementSystem system = new EmployeeManagementSystem(5);

        // Add employees
        system.addEmployee(new Employee(1, "Alice", "Developer", 70000));
        system.addEmployee(new Employee(2, "Bob", "Manager", 90000));
        system.addEmployee(new Employee(3, "Charlie", "Analyst", 60000));
        system.addEmployee(new Employee(4, "David", "Designer", 65000));
        system.addEmployee(new Employee(5, "Eve", "Developer", 70000));

        // Traverse employees
        System.out.println("Employee List:");
        system.traverseEmployees();

        // Search for an employee
        System.out.println("\nSearch for Employee with ID 3:");
        Employee emp = system.searchEmployee(3);
        if (emp != null) {
            System.out.println(emp);
        } else {
            System.out.println("Employee not found.");
        }

        // Delete an employee
        System.out.println("\nDeleting Employee with ID 2:");
        system.deleteEmployee(2);

        // Traverse employees after deletion
        System.out.println("\nEmployee List after Deletion:");
        system.traverseEmployees();
    }

}
