package inventory;

public class InventoryTest {
	public static void main(String[] args) {
        Inventory inventory = new Inventory();

        // Adding products
        Product product1 = new Product("P001", "Laptop", 10, 999.99);
        Product product2 = new Product("P002", "Smartphone", 25, 499.99);
        inventory.addProduct(product1);
        inventory.addProduct(product2);

        // Display all products
        System.out.println("All Products:");
        inventory.displayAllProducts();

        // Update a product
        Product updatedProduct = new Product("P001", "Gaming Laptop", 8, 1199.99);
        inventory.updateProduct(updatedProduct);

        // Display all products after update
        System.out.println("After Update:");
        inventory.displayAllProducts();

        // Delete a product
        inventory.deleteProduct("P002");

        // Display all products after deletion
        System.out.println("After Deletion:");
        inventory.displayAllProducts();
    }

}
