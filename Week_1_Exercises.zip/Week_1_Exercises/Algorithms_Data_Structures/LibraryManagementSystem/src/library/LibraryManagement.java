package library;

public class LibraryManagement {
	
    public static Book linearSearchByTitle(Book[] books, String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    
    public static Book binarySearchByTitle(Book[] books, String title) {
        int left = 0;
        int right = books.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int cmp = books[mid].getTitle().compareToIgnoreCase(title);

            if (cmp == 0) {
                return books[mid];
            } else if (cmp < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        
        Book[] books = {
            new Book(1, "Java Programming", "John Doe"),
            new Book(2, "Effective Java", "Joshua Bloch"),
            new Book(3, "Design Patterns", "Erich Gamma"),
            new Book(4, "Clean Code", "Robert C. Martin")
        };

        
        System.out.println("Linear Search:");
        Book foundBook = linearSearchByTitle(books, "Effective Java");
        if (foundBook != null) {
            System.out.println("Found: " + foundBook);
        } else {
            System.out.println("Book not found.");
        }

       
        System.out.println("\nBinary Search:");
       
        java.util.Arrays.sort(books, java.util.Comparator.comparing(Book::getTitle));
        foundBook = binarySearchByTitle(books, "Design Patterns");
        if (foundBook != null) {
            System.out.println("Found: " + foundBook);
        } else {
            System.out.println("Book not found.");
        }
    }
}
