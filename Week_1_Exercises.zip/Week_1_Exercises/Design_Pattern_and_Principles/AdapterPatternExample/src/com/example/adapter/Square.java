package com.example.adapter;

public class Square {
	 public void executePayment(double amount) {
	        System.out.println("Processing payment of $" + amount + " through Square.");
	    }

}
