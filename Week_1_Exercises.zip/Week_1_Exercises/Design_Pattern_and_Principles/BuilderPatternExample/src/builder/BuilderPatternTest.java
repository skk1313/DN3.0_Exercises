package builder;

public class BuilderPatternTest {
	
	        // Create a basic computer with only required attributes
	        Computer basicComputer = new Computer.Builder("Intel i5", "8GB")
	                                        .build();
	       System.out.println(basicComputer);

	        // Create a gaming computer with optional attributes
	        Computer gamingComputer = new Computer.Builder("Intel i9", "32GB")
	                                        .setStorage("1TB SSD")
	                                        .setGraphicsCard("NVIDIA RTX 3080")
	                                        .setPowerSupply("750W")
	                                        .setMotherboard("ASUS ROG")
	                                        .build();
	        System.out.println(gamingComputer);

	        // Create a workstation computer with different optional attributes
	        Computer workstationComputer = new Computer.Builder("AMD Ryzen 9", "64GB")
	                                            .setStorage("2TB NVMe")
	                                            .setGraphicsCard("AMD Radeon Pro")
	                                            .setPowerSupply("1000W")
	                                            .setMotherboard("MSI PRO")
	                                            .build();
	        System.out.println(workstationComputer);
	    }
	


	


