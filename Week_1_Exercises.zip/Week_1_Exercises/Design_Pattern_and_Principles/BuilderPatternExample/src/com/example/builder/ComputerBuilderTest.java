package com.example.builder;

public class ComputerBuilderTest {
	 public static void main(String[] args) {
	        // Create a basic computer configuration
	        Computer basicComputer = new Computer.Builder()
	            .setCPU("Intel i5")
	            .setRAM("8GB")
	            .setStorage("256GB SSD")
	            .build();

	        // Create a high-end computer configuration
	        Computer highEndComputer = new Computer.Builder()
	            .setCPU("Intel i9")
	            .setRAM("32GB")
	            .setStorage("1TB SSD")
	            .setGraphicsCard("NVIDIA RTX 3080")
	            .setOperatingSystem("Windows 11")
	            .build();

	        // Print details of the basic computer
	        System.out.println("Basic Computer Configuration:");
	        System.out.println("CPU: " + basicComputer.getCPU());
	        System.out.println("RAM: " + basicComputer.getRAM());
	        System.out.println("Storage: " + basicComputer.getStorage());
	        System.out.println();

	        // Print details of the high-end computer
	        System.out.println("High-End Computer Configuration:");
	        System.out.println("CPU: " + highEndComputer.getCPU());
	        System.out.println("RAM: " + highEndComputer.getRAM());
	        System.out.println("Storage: " + highEndComputer.getStorage());
	        System.out.println("Graphics Card: " + highEndComputer.getGraphicsCard());
	        System.out.println("Operating System: " + highEndComputer.getOperatingSystem());
	    }

}
