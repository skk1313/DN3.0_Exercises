package com.example.decorator;

public class NotifierTest {
	public static void main(String[] args) {
        Notifier emailNotifier = new EmailNotifier();
        Notifier smsNotifier = new SMSNotifierDecorator(emailNotifier);
        Notifier slackNotifier = new SlackNotifierDecorator(smsNotifier);

        System.out.println("Sending notification through Email:");
        emailNotifier.send("Hello, Email!");

        System.out.println("\nSending notification through Email and SMS:");
        smsNotifier.send("Hello, SMS!");

        System.out.println("\nSending notification through Email, SMS, and Slack:");
        slackNotifier.send("Hello, Slack!");
    }
}
