package com.example.dependencyinjection;

public class CustomerRepositoryImpl implements CustomerRepository{
	 @Override
	    public String findCustomerById(String id) {
	        // Simulate fetching customer from a database
	        return "Customer with ID: " + id;
	    }

}
