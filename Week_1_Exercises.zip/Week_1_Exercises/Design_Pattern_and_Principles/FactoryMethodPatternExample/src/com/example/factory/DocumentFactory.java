package com.example.factory;

public abstract class DocumentFactory {
	 public abstract Document createDocument();
}
