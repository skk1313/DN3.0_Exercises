package com.example.mvc;

public class MVCTest {
	public static void main(String[] args) {
        // Create the model
        Student model = retrieveStudentFromDatabase();

        // Create the view
        StudentView view = new StudentView();

        // Create the controller
        StudentController controller = new StudentController(model, view);

        // Display initial details
        controller.updateView();

        // Update model data
        controller.setStudentName("John Doe");
        controller.setStudentGrade("A+");

        // Display updated details
        controller.updateView();
    }

    private static Student retrieveStudentFromDatabase() {
        Student student = new Student();
        student.setName("Jane Doe");
        student.setId("12345");
        student.setGrade("B");
        return student;
    }

}
