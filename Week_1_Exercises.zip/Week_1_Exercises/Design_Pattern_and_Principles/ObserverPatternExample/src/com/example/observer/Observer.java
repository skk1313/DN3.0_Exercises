package com.example.observer;

public interface Observer {
	void update(double stockPrice);

}
