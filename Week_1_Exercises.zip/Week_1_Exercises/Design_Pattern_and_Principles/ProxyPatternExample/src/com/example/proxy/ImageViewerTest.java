package com.example.proxy;

public class ImageViewerTest {
	 public static void main(String[] args) {
	        Image image1 = new ProxyImage("http://example.com/image1.jpg");
	        Image image2 = new ProxyImage("http://example.com/image2.jpg");

	        // Display images
	        System.out.println("First time display:");
	        image1.display();
	        image2.display();

	        // Display images again to demonstrate caching
	        System.out.println("\nSecond time display:");
	        image1.display();
	        image2.display();
	    }

}
