package com.example.proxy;

public class RealImage implements Image  {
	  private String imagePath;

	    public RealImage(String imagePath) {
	        this.imagePath = imagePath;
	        loadImageFromServer();
	    }

	    private void loadImageFromServer() {
	        // Simulate loading image from a remote server
	        System.out.println("Loading image from server: " + imagePath);
	    }

	    @Override
	    public void display() {
	        System.out.println("Displaying image: " + imagePath);
	    }

}
